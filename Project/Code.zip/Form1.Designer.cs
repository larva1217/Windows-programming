﻿namespace Project_20215226
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtTask = new TextBox();
            button1 = new Button();
            button2 = new Button();
            chkTasks = new CheckedListBox();
            dtpDueDate = new DateTimePicker();
            cmbPriority = new ComboBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            cmbSort = new ComboBox();
            label4 = new Label();
            SuspendLayout();
            // 
            // txtTask
            // 
            txtTask.Location = new Point(72, 41);
            txtTask.Name = "txtTask";
            txtTask.Size = new Size(127, 23);
            txtTask.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(376, 94);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "ADD";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(376, 140);
            button2.Name = "button2";
            button2.Size = new Size(75, 23);
            button2.TabIndex = 2;
            button2.Text = "DELETE";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // chkTasks
            // 
            chkTasks.FormattingEnabled = true;
            chkTasks.Location = new Point(72, 82);
            chkTasks.Name = "chkTasks";
            chkTasks.Size = new Size(282, 346);
            chkTasks.TabIndex = 3;
            // 
            // dtpDueDate
            // 
            dtpDueDate.Location = new Point(205, 41);
            dtpDueDate.Name = "dtpDueDate";
            dtpDueDate.Size = new Size(160, 23);
            dtpDueDate.TabIndex = 4;
            // 
            // cmbPriority
            // 
            cmbPriority.FormattingEnabled = true;
            cmbPriority.Location = new Point(372, 41);
            cmbPriority.Name = "cmbPriority";
            cmbPriority.Size = new Size(109, 23);
            cmbPriority.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(116, 23);
            label1.Name = "label1";
            label1.Size = new Size(44, 15);
            label1.TabIndex = 6;
            label1.Text = "TO DO";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(274, 23);
            label2.Name = "label2";
            label2.Size = new Size(36, 15);
            label2.TabIndex = 7;
            label2.Text = "DATE";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(387, 23);
            label3.Name = "label3";
            label3.Size = new Size(81, 15);
            label3.TabIndex = 8;
            label3.Text = "IMPORTANCE";
            // 
            // cmbSort
            // 
            cmbSort.FormattingEnabled = true;
            cmbSort.Location = new Point(376, 206);
            cmbSort.Name = "cmbSort";
            cmbSort.Size = new Size(121, 23);
            cmbSort.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(415, 188);
            label4.Name = "label4";
            label4.Size = new Size(36, 15);
            label4.TabIndex = 10;
            label4.Text = "SORT";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(582, 450);
            Controls.Add(label4);
            Controls.Add(cmbSort);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(cmbPriority);
            Controls.Add(dtpDueDate);
            Controls.Add(chkTasks);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtTask);
            Name = "Form1";
            Text = "To Do List";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtTask;
        private Button button1;
        private Button button2;
        private CheckedListBox chkTasks;
        private DateTimePicker dtpDueDate;
        private ComboBox cmbPriority;
        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox cmbSort;
        private Label label4;
    }
}
