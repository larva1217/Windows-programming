using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Project_20215226
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            LoadTasks();

            cmbPriority.Items.Add("높음");
            cmbPriority.Items.Add("중간");
            cmbPriority.Items.Add("낮음");
            cmbPriority.SelectedIndex = 0;

            cmbSort.Items.Add("마감일 오름차순");
            cmbSort.Items.Add("마감일 내림차순");
            cmbSort.Items.Add("중요도 순");
            cmbSort.Items.Add("생성 순");
            cmbSort.SelectedIndex = 0;

            cmbSort.SelectedIndexChanged += cmbSort_SelectedIndexChanged;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtTask.Text) && cmbPriority.SelectedItem != null)
            {
                TaskItem item = new TaskItem()
                {
                    Text = txtTask.Text,
                    DueDate = dtpDueDate.Value,
                    Priority = cmbPriority.SelectedItem.ToString(),
                    CreatedDate = DateTime.Now
                };

                chkTasks.Items.Add(item, false);
                txtTask.Clear();
                cmbPriority.SelectedIndex = -1;

                SortTasks();
            }
            else
            {
                MessageBox.Show("할 일과 중요도를 모두 입력하세요.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            while (chkTasks.CheckedIndices.Count > 0)
            {
                chkTasks.Items.RemoveAt(chkTasks.CheckedIndices[0]);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            SaveTasks();
        }

        private void SaveTasks()
        {
            using (StreamWriter sw = new StreamWriter("tasks.txt"))
            {
                foreach (TaskItem task in chkTasks.Items)
                {
                    sw.WriteLine($"{task.Text} | {task.DueDate:yyyy-MM-dd} | {task.Priority} | {task.CreatedDate:O}");
                }
            }
        }

        private void LoadTasks()
        {
            if (File.Exists("tasks.txt"))
            {
                string[] lines = File.ReadAllLines("tasks.txt");
                chkTasks.Items.Clear();
                foreach (string line in lines)
                {
                    string[] parts = line.Split('|');
                    if (parts.Length == 4)
                    {
                        TaskItem task = new TaskItem()
                        {
                            Text = parts[0].Trim(),
                            DueDate = DateTime.Parse(parts[1].Trim()),
                            Priority = parts[2].Trim(),
                            CreatedDate = DateTime.Parse(parts[3].Trim())
                        };
                        chkTasks.Items.Add(task, false);
                    }
                }
                SortTasks();
            }
        }

        private void SortTasks()
        {
            List<TaskItem> tasks = new List<TaskItem>();

            foreach (TaskItem task in chkTasks.Items)
            {
                tasks.Add(task);
            }

            switch (cmbSort.SelectedItem.ToString())
            {
                case "마감일 오름차순":
                    tasks = tasks.OrderBy(t => t.DueDate).ToList();
                    break;

                case "마감일 내림차순":
                    tasks = tasks.OrderByDescending(t => t.DueDate).ToList();
                    break;

                case "중요도 순":
                    Dictionary<string, int> priorityMap = new Dictionary<string, int>()
                    {
                        { "높음", 3 },
                        { "중간", 2 },
                        { "낮음", 1 }
                    };
                    tasks = tasks.OrderByDescending(t => priorityMap[t.Priority]).ToList();
                    break;

                case "생성 순":
                    tasks = tasks.OrderBy(t => t.CreatedDate).ToList();
                    break;
            }

            chkTasks.Items.Clear();
            foreach (var task in tasks)
            {
                chkTasks.Items.Add(task, false);
            }
        }

        private void cmbSort_SelectedIndexChanged(object sender, EventArgs e)
        {
            SortTasks();
        }

 
    }

    public class TaskItem
    {
        public string Text { get; set; }
        public DateTime DueDate { get; set; }
        public string Priority { get; set; }
        public DateTime CreatedDate { get; set; }  

        public override string ToString()
        {
            return $"{Text} | {DueDate.ToShortDateString()} | {Priority}";
        }
    }
}
